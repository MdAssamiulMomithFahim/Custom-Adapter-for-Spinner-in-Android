# Custom-Adapter-for-Spinner-in-Android


It is simple project about spinner using custom adapter.
